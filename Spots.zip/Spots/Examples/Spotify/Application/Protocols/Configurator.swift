protocol Configurator {
  static func configure()
}
