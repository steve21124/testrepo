protocol Configurator {
  func configure()
}
